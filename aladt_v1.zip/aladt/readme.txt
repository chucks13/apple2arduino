-------------------------------------------------------------------------------
"Arme Leute Apple Disk Transfer"
Copyright (c) 2008 Sebastian Kienzl <seb at riot dot org>
2008-09-15
-------------------------------------------------------------------------------

These tools will enable you to backup your DOS (not ProDOS!) disks from your
Apple ][ and variants only using an audio-cable.

If you have more than 48k of memory (language card or other extension),
you're much better off with ADTPro (http://adtpro.sourceforge.net/).

If you neither have >= 64k of memory nor a serial card (like me!),
this is for you.

Please follow the instructions on my webpage: http://seb.riot.org
