#ifndef _WAVEOUT_H
#define _WAVEOUT_H

#include "types.h"

void enumerateWaveout();
void playWave( int sampleFreq, const u8* data, int sampleAmount, int device = -1 );

#endif
