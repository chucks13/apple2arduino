

    mac     pushxy
    sta		pusha_save	; 3
    txa					; 2
    pha					; 3
    tya					; 2
    pha					; 3
    lda		pusha_save	; 3
    endm ; = 16
    
	mac     popxy
    sta		pusha_save	; 3    
    pla					; 4
    tay					; 2
    pla					; 4
    tax					; 2
    lda		pusha_save	; 3
    endm ; = 18
;
	mac pushax
	pha
	txa
	pha
	endm
			
	mac popax
	pla
	tax
	pla
	endm

;
	mac pushay
	pha
	tya
	pha
	endm
	
	mac popay
	pla
	tay
	pla
	endm
