// hextodsk.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#define DSKSIZE (16*35*256)


int main(int argc,char **argv)
{
	FILE *in, *out;
	unsigned char outbuffer[DSKSIZE];
	in = fopen(argv[1], "rt");
	int state = 0;
	unsigned char c, b, v;
	v = 0;
	int idx = 0;

	while (!feof(in))
	{
		fread(&c, 1, 1, in);
//		printf("%c", c);
		if (c >= '0')
		{
			b = c - '0';
			if (b > 9)
			{
				b = (c - 'A') + 10;
			}
			if (state == 0)
				v = b * 16;
			else
			{
				v = v + b;
				outbuffer[idx++] = v;
				if ((idx & 255) == 0)
				{
					int track = idx / (16 * 256);
					int sector = (idx / 256) & 15;

					printf("%02X %02X\n", track, sector);
				}
				if (idx == DSKSIZE)
					break;
			}
			state = 1 - state;

		}
	}
	fclose(in);
	if (idx == DSKSIZE)
	{
		out = fopen(argv[2], "wb");
		fwrite(outbuffer, 1, DSKSIZE, out);
		fclose(out);
	}
    return 0;
}

